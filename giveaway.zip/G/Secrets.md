# Secret

`TOKEN` - Get your bot token at [Discord Developer Portal](https://discord.com/developers/applications), and paste the bot token in Secrets tab.

<br>
<br>

### Credits: ZeroSync